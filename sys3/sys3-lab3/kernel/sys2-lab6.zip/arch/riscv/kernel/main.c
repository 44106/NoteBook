#include <printk.h>
#include <sbi.h>
#include <private_kdefs.h>
extern void task_init(void);
_Noreturn void start_kernel(void) {
    task_init();
    printk("2025 ZJU Computer System II\n");
    // �ȴ���һ��ʱ���ж�
    while (1)
        ;
}
